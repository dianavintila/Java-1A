public class Exemplu1{
    public static void main (String [] args){
       byte b1; //declarare de variabila
       b1=10;
       
       byte b2=20; //initializare = declarare + atribuire
       short s1,s2,s3;
       int i1=10;
       long l1=10;
       int q1=04;//baza 8
       int q2=0xFA;//  baza 16 - hexa
       int q3=0b101001;//baza 2
       System.out.println(q2);
       long w=1_000_000;//same with
       long v=1000000;
       long k=100000000000L;//add L for long 
       float f1=10.5f;// same with 10.5F
       float f2=(float)10.5;
       double d1=10.5;
       boolean bool1=true;
       boolean bool2=false;
       char c1='a';
       char c2='\u0235';//codul din tabela
       char c3='\n';//caracter de linie noua
       System.out.println("Character "+c2);
       System.out.print("rand1");
       System.out.print("rand2");
       System.out.println("rand1");
       System.out.print("rand2");
       
       
       
       
    
    }



}